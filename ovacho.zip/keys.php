<?php 
//8264123179982660 - transarmor token for company card
define('PAYEEZY_API_PASSWORD', '8dP8HUx5Y2WT2X0n8FUcWqyphQK6t25P');
define('PAYEEZY_GATEWAY_ID', 'R63013-86');
define('PAYEEZY_HMAC_KEY', '8gcXLZ5CbbdvAi9I4rIQpwYWhVW4bN6T');
define('PAYEEZY_TRANSACTION_KEY', 'g4wh6ZaN8gL18rOdpSJG'); //for hash calculation of Payment Page
define('RELAY_RESPONSE_KEY', 'aYIJsyP0AIsQsbOkMD8e'); //in md5 hash calculation
define('PAYEEZY_GA_TRACKING_ID', 'UA-118022164-1');
define('FP_SEQUENCE', '15299628651372596775'); //x_fp_sequence
define('PAYEEZY_LOGIN', 'WSP-OVACH-v0gBWACqlA'); //x_login
define('CLASSIC_SUBSCRIPTION_ID', 'MB-OVACH-64-1020774');
define('DISCORD_URL', 'https://discord.gg/nxUB2Ec');
define('DISCORD_BOT_TOKEN', 'NDYxMzIwNTI2MjQ2MzEzOTk1.DhRl2w.XfFQni-TNzz9mcfpJ-oqo7PfZss');
define('FACEBOOK_URL', 'https://www.facebook.com/groups/OvachoInvestments/');
define('STOCKTWITS_URL', 'https://stocktwits.com/OvachoInvestments/');
define('DISCLAIMER_URL', 'https://docs.google.com/document/d/1Y4Wc7x-l9d1hCRKGumCRwUZfD8g5ePuwe1W_psLkB2c/edit?usp=sharing');
define('USER_DUMP_AUTH', 'HIAMD4Uu1DMAqXIUAyNfSv5sxmx2xETD57fSICCuXV9Q2SUI3Nth3VxgZHkiHJODSh9OJszjE3H4KQfygjFh2HqFAjH6aIgNqeNvl2y35nfy9LfXjtjjdF9Bx6tm1S6A3Mw17Wxq3hZonlMekwyHHGuqGk4JqNlKFtCsp0ZKiJybxIpAjRwiYE13tqmyhab1DGuAKq6AuMLBHpqaSl02VLD0Ga0RndUvNXdLYOfoQgL1TDOdLHoZQQnD37CaAkUdG3XHUJ03BsqIOJNN6APXd3vD21mvlof0OF8i6RyKcJNcBsS5shlkjD34EZ4BIMQL59pmvm7YXk1ndJRuRLiZ33nCtttMcTNCLrZ6SGDk2w5JzikJp0bCvJcwOSE6hDF2NbdQ3t81ez6Rgu5YN2Oa81cN9i1vMF4L3GLdUD70hNEQ2yLEfWTaP0gEKAKDhl0Rd3U0kcO5nTormHnTzu2V0A3JC5nIXrEuxvKklMFMjKuWMJh7FrivOoipr6hEBf5H2zfzagiu4JNaEHjEDYjTnas9KtNesSYjZ8DgcIg5eIqJFinH927how0h1oOvucqlqIt6oVwtpt5tRvuR8unimELfjRuP6awJnlgZ2pnXGG7Wo3B3f88OcAmvqJgLbFIU838XT2r5vq8rlZL8zGYAuwzUZMcrfTAlxhmqIDFYNzMMStKogSKpZ0Tm5frSze60u61M3g6CW2IiLKepmPXMAE3q0Ok8fwyVGin1zEbCqqbrZDDlfEkaEbQUSnVQO1KFlQRy5RBluybQG5mlW1TY0CMQcPzilYfmuoRGPLA1ATWPmsXfgXoht2kIjeSEgSW5EN0k2WQflRC3LFwYFySF3ct3AQa99KvZdAZcxNdd222EQgr92mUsMKjrJLGJmi15zruJtVOWY4RTxN1otxb7QAG02URAsyqCffMKcnCtdjsDcaxCcGtgN5Wxrmcz86RfznDef4uznU52FbWbOFsokWN1X5KDgHc8A7BGVOsCe3KKD4TFjVPj8EkntlLCcClX');
?>