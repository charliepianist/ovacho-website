<?php /*Template Name: Payment Landing **Backend** */ ?>
<!DOCTYPE html>
<html data-wf-page="5acbac765edee8052c0d9efc" data-wf-site="5a7fa1f338edac00018725fb">
<?php get_header(); ?>
	<div class="_3_container w-container">
	<h1 class="heading_login_error">Thank you for your purchase!</h1>
    <p class="paragraph_login_error">Thank you for purchasing Classic Subscription. A receipt email has been sent to the address provided.<br>Good luck trading and we hope you find our resources helpful!<br><br><a href="<?php echo site_url(); ?>" style="color: #fff;">Back to Site Home</a></p>
	</div>
<?php get_footer(); ?>