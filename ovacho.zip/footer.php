<div id="1_6" class="_1_6" style="display: none;">
    <div class="_1_container5 w-container"><a href="<?php bloginfo('url'); ?>/terms/" class="_1_button_policies w-button">Disclaimer  <span class="text-span-5">○</span>  </a><a href="<?php bloginfo('url'); ?>/terms/" class="_1_button_policies w-button">Terms  <span class="text-span-4">○</span>  </a><a href="<?php bloginfo('url'); ?>/privacy-policy/" class="_1_button_policies w-button">Privacy Policy  <span class="text-span-6">○</span>  </a><a href="#" class="_1_button_policies w-button">FAQ</a>
      <p class="_1_disclaimers"><span class="text-span"></span>© 2018 Ovacho LLC. All Rights Reserved.<span class="text-span"> <br></span></p>
    </div>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js" type="text/javascript"></script>
  <script type="text/javascript">WebFont.load({  google: {    families: ["Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic","Varela:400","Roboto:300,regular,500","Roboto Slab:regular"]  }});</script>
  <script src="https://use.typekit.net/ddt5dse.js" type="text/javascript"></script>
  <script type="text/javascript">try{Typekit.load();}catch(e){}</script>
  <!-- [if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" type="text/javascript" intergrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script src="<?php bloginfo('stylesheet_directory');?>/js/webflow.js" type="text/javascript"></script>
  <script>
    $('document').ready(function() {
      var viewport_height = $(window).height();
    var document_height = $(document).height();
    if(document_height > viewport_height) {
      $('#1_6').addClass('_1_6r');
      $('#1_6').removeClass('_1_6');
    }
    $('#1_6').css('display', '');
    })
    

  </script>
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
  <?php wp_footer(); ?>
</body>
</html>