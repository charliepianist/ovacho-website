<?php /*Template Name: Discord **Backend** */ ?>
<!--  Last Published: Tue Apr 10 2018 01:20:11 GMT+0000 (UTC)  -->
<!DOCTYPE html>
<html data-wf-page="5acbc4be54d3f49c91869741" data-wf-site="5a7fa1f338edac00018725fb">
<?php get_header(); ?>
  <div class="_3_container w-container">
    <h1 class="heading">Discord Group</h1>
    <p class="paragraph_privacy1">We hope that our products spark conversations and build a community of traders and enthusiasts.<span class="text-span-3"><br></span></p><a href="<?php echo DISCORD_URL; ?>" data-w-id="4ebf864f-b577-a141-75ce-b525686242dc" class="_3_wlr-archive w-button">Discord Group</a><img src="<?php bloginfo('stylesheet_directory');?>/images/IMG_5728_iphone7plusrosegold_portrait.png" width="500" height="500" srcset="<?php bloginfo('stylesheet_directory');?>/images/IMG_5728_iphone7plusrosegold_portrait-p-500.png 500w, <?php bloginfo('stylesheet_directory');?>/images/IMG_5728_iphone7plusrosegold_portrait-p-800.png 800w, images/IMG_5728_iphone7plusrosegold_portrait-p-1080.png 1080w, <?php bloginfo('stylesheet_directory');?>/images/IMG_5728_iphone7plusrosegold_portrait-p-1600.png 1600w, <?php bloginfo('stylesheet_directory');?>/images/IMG_5728_iphone7plusrosegold_portrait.png 2000w" sizes="(max-width: 479px) 53vw, (max-width: 767px) 55vw, 500px" class="image-5"></div>
  </div>
<?php get_footer(); ?>