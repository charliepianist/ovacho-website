<div class="_3_container w-container">
	<h1 class="heading_login_error">Already Logged In</h1>
    <p class="paragraph_login_error">Error: You are already logged in. <a href="<?php bloginfo('url');?>" style="color: #fff;">Site Home</a><span class="text-span-3"><br></span></p>
</div>