<div class="_3_container w-container">
	<h1 class="heading_login_error">Subscription Expired</h1>
    <p class="paragraph_login_error">Your Classic Subscription has expired. Please <a href="<?php echo site_url('pricing');?>" style="color: #fff;">renew your subscription</a> or reload the page to view <strong><?php echo str_replace('<<', '', wp_title('', false)); ?></strong>. Thanks!<span class="text-span-3"><br></span></p>
</div>